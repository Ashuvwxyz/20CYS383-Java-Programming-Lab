package com.amrita.jpl.cys21012.endsem;

import javax.lang.model.type.NullType;

public class file {
    String filename;
    String filesize;

    public file(){};

    public file(String fname, String fsize){
        filename = fname;
        filesize = fsize;
    }

    void displayFileDetails(){};
}
