package com.amrita.jpl.cys21012.ex;

public class Flag {
    public  static  void main(String[] args){
        for (int i=0;i<4;i++){
            System.out.println("* * * * * * ==================================");
            System.out.println("* * * * *  ===================================");
        }

        System.out.println("* * * * * * ==================================");

        for (int j=0;j<5;j++){
            System.out.println("==============================================");
        }

    }
}
