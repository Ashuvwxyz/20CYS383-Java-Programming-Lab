package com.amrita.jpl.cys21012.pract.general;

public class HelloWorld {

    int x = 5;
    int y = 10;
    public static void main(String[] args){

        System.out.println("Hello World!");
        HelloWorld test = new HelloWorld();
        System.out.println(test.y);

    }

}
